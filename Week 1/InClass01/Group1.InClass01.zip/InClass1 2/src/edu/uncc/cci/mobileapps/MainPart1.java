//      a. Assignment #.1.1
//      b. File Name.MainPart1
//      c. Full name of the student: Kiran Koirala, Curtrina Howell

package edu.uncc.cci.mobileapps;

import java.util.ArrayList;
import java.util.Collections;

public class MainPart1 {
    /*
    * Question 1:
    * - In this question you will use the Data.users array that includes
    * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
    * - Create a User class that should parse all the parameters for each user.
    * - Insert each of the users in a list.
    * - Print out the TOP 10 oldest users.
    * */

    public static void main(String[] args) {
        ArrayList<User> list = new ArrayList<>();

        //example on how to access the Data.users array.
        for (String str : Data.users) {
            String[] data = str.split(",");
            User user = new User(data[0], data[1], Integer.parseInt(data[2]), data[3], data[4], data[5], data[6]);
            list.add(user);

        }

        Collections.sort(list);
        //int i = list.size()-1; i > list.size()-11; i--
        for (int i = list.size()-1; i > list.size()-11; i--){
            System.out.println(list.get(i));
        }
    }
}