//      a. Assignment #.1.3
//      b. File Name.MainPart3
//      c. Full name of the student: Kiran Koirala, Curtrina Howell

        package edu.uncc.cci.mobileapps;

import java.util.ArrayList;
import java.util.HashSet;

public class MainPart3 {
    /*
    * Question 3:
    * - This is a simple programming question that focuses on finding the
    * longest increasing subarray. Given the array A = {1,2,3,2,5,2,4,6,7} the
    * longest increasing subarray is {2,4,6,7}, note that the values have to be
    * contiguous.
    * */

    public static void main(String[] args) {
        //example call
        //int[] input = {}; // output {}
        //int[] input = {1}; // output {1}
        //int[] input = {1,2,3,4}; // output {1,2,3,4}
        //int[] input = {1,2,3,4,4,4,4,4,5,6}; // output {1,2,3,4}
        //int[] input = {1,2,3,-1,4,5,8,20,25,1,1,4,6}; // output {-1,4,5,8,20,25}
        //int[] input = {1,2,3,1,1,1,2,3,4,1,1,2,4,6,7}; // output{1,2,4,6,7}
        int[] input = {1,2,3,2,5,2,4,6,7}; // output {2,4,6,7}
        int[] result = printLongestSequence(input);
        for (int i = 0; i < result.length; i++){
            System.out.println(result[i]);
        }
    }

    public static int[] printLongestSequence(int[] input){

        int[] result = {};
        int length = input.length;

        if (length == 0){
            return result;
        }
        if (length == 1){
            return input;
        }

        HashSet<ArrayList> hashSet = new HashSet<ArrayList>();


        int lastNum = -1000000;

        for (int i: input){
            ArrayList<Integer> arrayList = new ArrayList<Integer>();;
            if (input[i] < lastNum){
                arrayList.add(input[i]);
                lastNum = input[i];
            }
            else{
                hashSet.add(arrayList);
                arrayList.clear();
                lastNum = -10000000;
            }
        }


        ArrayList<ArrayList> list = new ArrayList(hashSet);
        ArrayList<Integer> count = new ArrayList<>();
        for (ArrayList<Integer> lst: list){
            count.add(lst.size());
        }
        int maxIndex = 0;
        for (int i = 0; i < count.size(); i++){
            if (count.get(i) > count.get(maxIndex)){
                maxIndex = i;
            }
        }

        ArrayList<Integer> maxArrayList = list.get(maxIndex);
        int[] array = new int[maxArrayList.size()];
        for (int i = 0; i < maxArrayList.size(); i++){
            array[i] = (int)maxArrayList.get(i);
        }

        return array;


    }
}