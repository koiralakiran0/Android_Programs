//      a. Assignment #.1.1
//      b. File Name. User
//      c. Full name of the student: Kiran Koirala, Curtrina Howell


package edu.uncc.cci.mobileapps;

public class User implements Comparable<User>{

    String firstname;
    String lastname;
    int age;
    String email;
    String gender;
    String city;
    String state;

    public User(String firstname, String lastname, int age, String email, String gender, String city, String state) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
        this.email = email;
        this.gender = gender;
        this.city = city;
        this.state = state;
    }

    @Override
    public int compareTo(User o) {
        return this.age-o.age;
    }

    @Override
    public String toString() {
        return "User{" +
                "firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", age=" + age +
                ", email='" + email + '\'' +
                ", gender='" + gender + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
