//      a. Assignment #.1.2
//      b. File Name.MainPart2
//      c. Full name of the student: Kiran Koirala, Curtrina Howell

package edu.uncc.cci.mobileapps;

import java.util.*;

public class MainPart2 {
    /*
    * Question 2:
    * - In this question you will use the Data.users array that includes
    * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
    * - Create a User class that should parse all the parameters for each user.
    * - The goal is to count the number of users living each state.
    * - Print out the list of State, Count order in ascending order by count.
    * */

    public static void main(String[] args) {
        //HashMap<String, ArrayList> map = new HashMap<String, ArrayList>();

        HashMap<String, Integer> map = new HashMap<String, Integer>();
        //example on how to access the Data.users array.
        for (String str : Data.users) {
            String[] data = str.split(",");
            User user = new User(data[0], data[1], Integer.parseInt(data[2]), data[3], data[4], data[5], data[6]);
            if (map.get(data[6]) != 0){
                //ArrayList<User> arrayList = map.get(data[6]);
                //arrayList.add(user);
                map.put(data[6], map.get(data[6]) + 1);
            }
            else{
                //ArrayList<User> arrList = new ArrayList<User>();
                //arrList.add(user);
                map.put(data[6], 1);
            }
        }

        ValueComparator bvc = new ValueComparator(map);
        TreeMap<String, Integer> sorted_map = new TreeMap<String, Integer>(bvc);
        //Set keys = map.keySet();


        sorted_map.putAll(map);

        //String[] keyset = sorted_map.keySet().toArray(new String[0]);

        System.out.println(sorted_map);



    }
}

class ValueComparator implements Comparator<String> {
    Map<String, Integer> base;

    public ValueComparator(Map<String, Integer> base) {
        this.base = base;
    }

    // Note: this comparator imposes orderings that are inconsistent with
    // equals.
    public int compare(String a, String b) {
        if (base.get(a) >= base.get(b)) {
            return -1;
        } else {
            return 1;
        } // returning 0 would merge keys
    }
}