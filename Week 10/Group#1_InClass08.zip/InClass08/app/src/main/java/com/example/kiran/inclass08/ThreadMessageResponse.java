

package com.example.kiran.inclass08;

import java.util.ArrayList;

/**
 * Created by kiran on 11/6/17.
 */

public class ThreadMessageResponse {
    private ArrayList<MessageThread> threads;

    public ArrayList<MessageThread> getThreads() {
        return threads;
    }
}
