package com.example.koira.inclass06;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by koira on 10/23/2017.
 */

public class ArticlesAdapter extends RecyclerView.Adapter<ArticlesAdapter.ViewHolder> {

    ArrayList<Article> mData;

    public ArticlesAdapter(ArrayList<Article> mData) {
        this.mData = mData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.article_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Article article = mData.get(position);
        holder.textViewAuthor.setText(article.getAuthor());
        holder.textViewTitle.setText(article.getTitle());
        holder.textViewPublishedAt.setText(article.getPublishedAt());
        holder.article = article;

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewAuthor, textViewPublishedAt;
        ImageView imageViewPic;
        Article article;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewAuthor = itemView.findViewById(R.id.textViewAuthor);
            textViewPublishedAt = itemView.findViewById(R.id.textViewPublishedAt);
            imageViewPic = itemView.findViewById(R.id.imageView_displayImage);

            //SET ON CLICKLISTENER
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Uri uri = Uri.parse(article.getUrl());
                    //Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    //startActivity(intent);
                    Log.d("demo", "clicked");
                }
            });
        }
    }
}